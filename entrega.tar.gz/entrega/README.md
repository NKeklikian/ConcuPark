# ConcuPark
Repositorio para el primer proyecto de 75.59 Tecnicas de programacion concurrente

Para correrlo compilar y poner el archivo config.txt al mismo nivel que el ejecutable. El logof.sh solo hace grep de un nombre o pid para ver mas claro el log.txt
